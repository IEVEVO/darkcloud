# DarkCloud: Soundcloud Night Mode
Browser extension that changes soundcloud.com to a dark theme.

Available for <a href="https://addons.mozilla.org/en-US/firefox/addon/darkcloud/">Firefox</a> and <a href="https://addons.opera.com/en-gb/extensions/details/darkcloud/">Opera</a>.<br>
For Chrome download/install and more info, go <a href="http://deathgrips.dx.am/darkcloud.php">here</a>.
